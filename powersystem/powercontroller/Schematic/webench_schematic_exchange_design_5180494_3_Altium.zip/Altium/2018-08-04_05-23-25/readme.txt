 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: Z:\\51\\80\\5180494\\3\Altium\2018-08-04_05-23-25\2018-08-04_05-23-25
 
 
**********************************************************
***************** Schematic Instructions  ****************
**********************************************************

To import your new Schematic into Altium:

1. Unzip the downloaded folder files to a local directory and
Start the Altium program.
2. From the menu select "File"->"Open".
3. Select the file named in the path above ending with ".schdoc"
and "Open" the file.
4. Your Schematic should be viewable within Altium now.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_BrdSch_import.html



**********************************************************
*******************  PCB Instructions  *******************
**********************************************************


To import your new BOARD into Altium:

1. Unzip the downloaded folder files to a local directory
	and Start the Altium program.
2. From the menu select "File"->"Open".
3. Select the file named in the path above ending with ".pcbdoc"
and "Open" the file.
4. Planes will need to be repoured to update the Copper Pour Polygons
	a. Once your board is loaded, select the Tools menu from the
	   top Menu Bar
	b. Scroll to the Polygon Pours item on the Tools Menu.
	c. The Polygon Pours item should expand to show more options
	d. Select Repour All Polygons, this will repour all of the
	   polygons.
5. Your board should be viewable within Altium now.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_BrdSch_import.html

**********************************************************
*******************  LIB Instructions  *******************
**********************************************************

To import your new LIBRARY PARTS into Altium follow these steps:

1. After running the Ultra Librarian export for the first time,
you will need to copy the following files into an area where
they can be accessed for all future translations.  They are script
files that Altium will need to be able to find.
	a. UL_Form.dfm
	b. UL_Form.pas
	c. UL_Import.pas
	d. UL_Import.prjScr
2. The above script file will need to be run from within Altium.
This can be done by going to File, Open and selecting the
UL_Import.PrjScr file stored above.
3. Select the "DXP" dropdown menu in the top-left corner runfrom
the drop down menu and select "Run Script". Select "UL_Form.pas"
and click "OK"
4. When the script is run, it will ask you for the file name of the
Ultra Librarian file to run. Click "File...", select the latest file
produced with a date code (for instance 2010-02-17_23-12-34.txt), and
click "Start Import".
5. The script will open a new Integraged Library project and import
the Ultra Librarian data into it.  When complete a message box
will pop up saying that import is done.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_import.html

For a video tutorial, please visit:
http://youtu.be/pih50yx9HYU

**********************************************************
**********************************************************
**********************************************************
 
 
Padstack "RX263p78Y299p4D0T" renamed to "RX263p78Y299p4D0"
Symbol "WB_DIODE_SCHOTTKY" renamed to "WB_DIODE_SCHOTTK"
Symbol "WB_PWL_VOLTAGE_SOURCE" renamed to "WB_PWL_VOLTAGE_S"
Symbol "WB_SOURCE_RESISTOR" renamed to "WB_SOURCE_RESIST"
Symbol "WB_PRIM_PWL_VOLTAGE_SOURCE" renamed to "WB_PRIM_PWL_VOLT"
Symbol "WB_PRIM_STARTUP_VOLTAGE_SOURCE" renamed to "WB_PRIM_STARTUP_"
Symbol "WB_STARTUP_VOLTAGE_SOURCE" renamed to "WB_STARTUP_VOLTA"
Symbol "WB_PWL_CURRENT_LOAD" renamed to "WB_PWL_CURRENT_L"
Symbol "WB_PRIMITIVE_BATTERY" renamed to "WB_PRIMITIVE_BAT"
Component "WB_CURRENT_LOAD" renamed to "WB_CURRENT_LOAD"
Component "EEHZA1H101P" renamed to "EEHZA1H101P"
Component "CL21C621JBCNNNC" renamed to "CL21C621JBCNNNC"
Component "TMK212B7105KG-T" renamed to "TMK212B7105KG-T"
Component "EMK212B7474KD-T" renamed to "EMK212B7474KD-T"
Component "CSD19534Q5A" renamed to "CSD19534Q5A"
Component "ERJ-6ENF1001V" renamed to "ERJ-6ENF1001V"
Component "ERJ-6ENF8661V" renamed to "ERJ-6ENF8661V"
Component "CRCW040264K9FKED" renamed to "CRCW040264K9FKED"
Component "CL05C181JB5NNNC" renamed to "CL05C181JB5NNNC"
Component "CGA4J2X7R2A104K125AA" renamed to "CGA4J2X7R2A104K1"
Component "CRCW04029K31FKED" renamed to "CRCW04029K31FKED"
Component "CSD16327Q3" renamed to "CSD16327Q3"
Component "RC0201FR-0756K2L" renamed to "RC0201FR-0756K2L"
Component "CRCW04021M02FKED" renamed to "CRCW04021M02FKED"
Component "PRL1632-R013-F-T1" renamed to "PRL1632-R013-F-T"
Component "LM5118MH/NOPB" renamed to "LM5118MH/NOPB"
Component "SB10150TA" renamed to "SB10150TA"
Component "SER2915L-153KL" renamed to "SER2915L-153KL"
Component "C2012C0G1H223K125AA" renamed to "C2012C0G1H223K12"
Component "CL10C122JB8NNNC" renamed to "CL10C122JB8NNNC"
Component "08053C104JAZ2A" renamed to "08053C104JAZ2A"
Component "WB_GND" renamed to "WB_GND"
Component "SBRD10200TR" renamed to "SBRD10200TR"
Component "RC0201FR-0736K5L" renamed to "RC0201FR-0736K5L"
Component "WB_BATTERY" renamed to "WB_BATTERY"
Component "C5750X7S2A106K230KB" renamed to "C5750X7S2A106K23"
The Symbol WB_CONTINUATION was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CONTINUATION was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CONTINUATION was missing a Value attribute, a value was created for the symbol.
The Symbol WB_N_MOSFET was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_N_MOSFET was missing a Type attribute, a type was created for the symbol.
The Symbol WB_N_MOSFET was missing a Value attribute, a value was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LM5118 was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LM5118 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LM5118 was missing a Value attribute, a value was created for the symbol.
The Symbol WB_BLOCK_IO was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Type attribute, a type was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_VOLTAGE_S was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PWL_VOLTAGE_S was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_VOLTAGE_S was missing a Value attribute, a value was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a Type attribute, a type was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_PWL_VOLT was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_PWL_VOLT was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_PWL_VOLT was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_STARTUP_ was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_STARTUP_ was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_STARTUP_ was missing a Value attribute, a value was created for the symbol.
The Symbol WB_STARTUP_VOLTA was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_STARTUP_VOLTA was missing a Type attribute, a type was created for the symbol.
The Symbol WB_STARTUP_VOLTA was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_CURRENT_L was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PWL_CURRENT_L was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_CURRENT_L was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a Value attribute, a value was created for the symbol.
The Symbol LM5118MH/NOPB was missing a Value attribute, a value was created for the symbol.


Ultra Librarian Gold 8.1.204 Process Report


Message - Symbol "WB_CAPACITOR" has as multiple attributes named "TYPE".
One of the attributes was renamed to "TYPE_2".
Message - Component "EEHZA1H101P" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EEHZA1H101P" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EEHZA1H101P" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EEHZA1H101P" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EEHZA1H101P" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C621JBCNNNC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C621JBCNNNC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C621JBCNNNC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C621JBCNNNC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C621JBCNNNC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212B7105KG-T" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212B7105KG-T" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212B7105KG-T" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212B7105KG-T" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK212B7474KD-T" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK212B7474KD-T" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK212B7474KD-T" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK212B7474KD-T" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1001V" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1001V" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1001V" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF8661V" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF8661V" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF8661V" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040264K9FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040264K9FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040264K9FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL05C181JB5NNNC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL05C181JB5NNNC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL05C181JB5NNNC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL05C181JB5NNNC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL05C181JB5NNNC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CGA4J2X7R2A104K1" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CGA4J2X7R2A104K1" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CGA4J2X7R2A104K1" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CGA4J2X7R2A104K1" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CGA4J2X7R2A104K1" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04029K31FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04029K31FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04029K31FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD16327Q3" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD16327Q3" attribute "VdsMax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD16327Q3" attribute "IdsMax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD16327Q3" attribute "Rdson45" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD16327Q3" attribute "QgTyp" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD16327Q3" attribute "Quantity" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0756K2L" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0756K2L" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0756K2L" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0756K2L" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04021M02FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04021M02FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04021M02FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R013-F-T" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R013-F-T" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R013-F-T" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R013-F-T" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM5118MH/NOPB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM5118MH/NOPB" attribute "Frequency" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM5118MH/NOPB" attribute "Imax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM5118MH/NOPB" attribute "Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM5118MH/NOPB" attribute "Mktg_Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM5118MH/NOPB" attribute "NSID" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SB10150TA" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SB10150TA" attribute "Io" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SB10150TA" attribute "VRRM" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SB10150TA" attribute "VFatIo" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SER2915L-153KL" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SER2915L-153KL" attribute "L" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SER2915L-153KL" attribute "DCR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SER2915L-153KL" attribute "IDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012C0G1H223K12" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012C0G1H223K12" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012C0G1H223K12" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012C0G1H223K12" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012C0G1H223K12" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL10C122JB8NNNC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL10C122JB8NNNC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL10C122JB8NNNC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL10C122JB8NNNC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL10C122JB8NNNC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "08053C104JAZ2A" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "08053C104JAZ2A" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "08053C104JAZ2A" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "08053C104JAZ2A" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "08053C104JAZ2A" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SBRD10200TR" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SBRD10200TR" attribute "Io" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SBRD10200TR" attribute "VRRM" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SBRD10200TR" attribute "VFatIo" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0736K5L" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0736K5L" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0736K5L" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0736K5L" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C5750X7S2A106K23" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C5750X7S2A106K23" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C5750X7S2A106K23" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C5750X7S2A106K23" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C5750X7S2A106K23" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.

TextStyle count:  24
Padstack count:   18
Pattern count:    13
Symbol count:     26
Component count:  27

Export

Footprint "0805" has no layer data mapped and will be skipped.
Component "CL21C621JBCNNNC" requires footprint "0805" and will be skipped.
Component "TMK212B7105KG-T" requires footprint "0805" and will be skipped.
Component "EMK212B7474KD-T" requires footprint "0805" and will be skipped.
Component "ERJ-6ENF1001V" requires footprint "0805" and will be skipped.
Component "ERJ-6ENF8661V" requires footprint "0805" and will be skipped.
Component "CGA4J2X7R2A104K1" requires footprint "0805" and will be skipped.
Component "C2012C0G1H223K12" requires footprint "0805" and will be skipped.
Component "08053C104JAZ2A" requires footprint "0805" and will be skipped.
Footprint "0402" has no layer data mapped and will be skipped.
Component "CRCW040264K9FKED" requires footprint "0402" and will be skipped.
Component "CL05C181JB5NNNC" requires footprint "0402" and will be skipped.
Component "CRCW04029K31FKED" requires footprint "0402" and will be skipped.
Component "CRCW04021M02FKED" requires footprint "0402" and will be skipped.
Footprint "0201" has no layer data mapped and will be skipped.
Component "RC0201FR-0756K2L" requires footprint "0201" and will be skipped.
Component "RC0201FR-0736K5L" requires footprint "0201" and will be skipped.
Footprint "0603" has no layer data mapped and will be skipped.
Component "CL10C122JB8NNNC" requires footprint "0603" and will be skipped.
Warning: Symbol "WB_CAP_POLARIZED" attribute "Cap" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "ESR" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "IRMS" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "VDC" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "PN" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "DEV" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "VAL" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "TOL" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "RefDes2" references missing text style ""
Warning: Symbol "CSD19534Q5A" attribute "PN" references missing text style ""
Warning: Symbol "CSD19534Q5A" attribute "DEV" references missing text style ""
Warning: Symbol "CSD19534Q5A" attribute "VAL" references missing text style ""
Warning: Symbol "CSD19534Q5A" attribute "TOL" references missing text style ""
Warning: Symbol "CSD19534Q5A" attribute "RefDes2" references missing text style ""
Warning: Symbol "CSD16327Q3" attribute "TOL" references missing text style ""
Warning: Symbol "CSD16327Q3" attribute "VAL" references missing text style ""
Warning: Symbol "CSD16327Q3" attribute "DEV" references missing text style ""
Warning: Symbol "CSD16327Q3" attribute "PN" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Resistance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Power" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Tolerance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "RefDes2" references missing text style ""
Warning: Symbol "LM5118MH/NOPB" attribute "PN" references missing text style ""
Warning: Symbol "LM5118MH/NOPB" attribute "DEV" references missing text style ""
Warning: Symbol "LM5118MH/NOPB" attribute "VAL" references missing text style ""
Warning: Symbol "LM5118MH/NOPB" attribute "TOL" references missing text style ""
Warning: Symbol "LM5118MH/NOPB" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "Io" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "VRRM" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "VFatIo" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "TOL" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "VAL" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "DEV" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "PN" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "L" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "DCR" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "IDC" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "RefDes2" references missing text style ""
Warning: Symbol "SBRD10200TR" attribute "Io" references missing text style ""
Warning: Symbol "SBRD10200TR" attribute "VRRM" references missing text style ""
Warning: Symbol "SBRD10200TR" attribute "VFatIo" references missing text style ""
Warning: Symbol "SBRD10200TR" attribute "PN" references missing text style ""
Warning: Symbol "SBRD10200TR" attribute "DEV" references missing text style ""
Warning: Symbol "SBRD10200TR" attribute "VAL" references missing text style ""
Warning: Symbol "SBRD10200TR" attribute "TOL" references missing text style ""
Warning: Symbol "SBRD10200TR" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "Cap" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "ESR" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "IRMS" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VDC" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "RefDes2" references missing text style ""
